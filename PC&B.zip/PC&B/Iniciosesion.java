import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

public class Iniciosesion {
    public static void main(String[] args) {
       
        JFrame frame = new JFrame("Inicio Sesión");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Abre la ventana en pantalla completa
        frame.getContentPane().setBackground(new Color(65, 105, 225));
        frame.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10); // Márgenes 
        gbc.anchor = GridBagConstraints.CENTER;

         //imagen
        ImageIcon imagenOriginal = new ImageIcon("img/iconobom.png");
        Image imagentamaño = imagenOriginal.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);//cambia el tamaño de la imgen
        JLabel labelImagen = new JLabel(new ImageIcon(imagentamaño));
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        frame.add(labelImagen, gbc);
        
        // Título
        JLabel titulo = new JLabel("Inicio de Sesión");
        titulo.setFont(new Font("Monserrat", Font.BOLD, 40));
        titulo.setForeground(Color.WHITE);
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        frame.add(titulo, gbc);
        
        JLabel texto = new JLabel("Usuario:");
        texto.setFont(new Font("Arial", Font.BOLD, 14));
        texto.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(20, 10, 2, 10); // espacios
        frame.add(texto, gbc);
        
        //campos
        JTextField campoTexto = new JTextField();
        campoTexto.setPreferredSize(new Dimension(200, 30));
        
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 10, 15, 10); 
        frame.add(campoTexto, gbc);
        
        
        JLabel texto2 = new JLabel("Contraseña:");
        texto2.setFont(new Font("Arial", Font.BOLD, 14));
        texto2.setForeground(Color.BLACK);
        
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 10, 2, 10); 
        frame.add(texto2, gbc);
        
        
        JPasswordField campoTexto1 = new JPasswordField();
        campoTexto1.setPreferredSize(new Dimension(200, 30));
        
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 10, 20, 10); // Espacio abajo
        frame.add(campoTexto1, gbc);
        
        // Bboton
        JButton boton = new JButton("Iniciar Sesión");
        boton.setPreferredSize(new Dimension(150, 40));
        boton.setFont(new Font("Arial", Font.BOLD, 16));
        boton.setBackground(new Color(105,105,105));
        boton.setForeground(Color.BLACK);
        boton.addActionListener(e -> {
        String usuario = campoTexto.getText();
        char[] passwordChars = campoTexto1.getPassword();
        String password = new String(passwordChars); // Convertimos char[] a String

        // Validar campos vacíos
        if (usuario.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(frame, "Por favor, complete todos los campos", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
        return; // Salir del ActionListener sin continuar
        }

        // Validar credenciales
        if(usuario.equals("admin") && password.equals("123456")) {
        frame.dispose(); // Cierra la ventana actual
        menu.main(null); // Abre la ventana del menú principal
        } else {
        JOptionPane.showMessageDialog(frame, "Usuario o contraseña incorrectos", "Error de inicio de sesión", JOptionPane.ERROR_MESSAGE);
        // Limpiar los campos de texto
        campoTexto.setText("");
        campoTexto1.setText("");
        }
    });

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 10, 10);
        frame.add(boton, gbc);

        frame.setVisible(true);
    }
}