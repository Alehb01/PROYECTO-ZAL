import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Image;

public class Inicio {
    public static void main(String[] args) {
       
        JFrame frame = new JFrame("Inicio");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Abre la ventana en pantalla completa
        frame.getContentPane().setBackground(new Color(65,105,225));
        frame.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER; // Centrar todos los componentes

        //imagen
        ImageIcon imagenOriginal = new ImageIcon("img/logoP.png");
        Image imagentamaño = imagenOriginal.getImage().getScaledInstance(300, 300, Image.SCALE_SMOOTH);//cambia el tamaño de la imgen
        JLabel labelImagen = new JLabel(new ImageIcon(imagentamaño));
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        frame.add(labelImagen, gbc);
        
        // Título
        JLabel titulo = new JLabel("Pc&B");
        titulo.setFont(titulo.getFont().deriveFont(100f)); //Cambia el tamaño del texto
        titulo.setForeground(Color.DARK_GRAY);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        gbc.gridy = 1;
        frame.add(titulo, gbc);
        
        // Botones
        JButton boton = new JButton("Iniciar Sesión");
        boton.setPreferredSize(new Dimension(250, 50)); // cambiar el tamaño del botón
        boton.setFont(boton.getFont().deriveFont(18f)); // Cambiar tamaño del texto
        boton.setBackground(new Color(245, 255, 250)); // Cambiar el color del botón
        boton.setForeground(Color.BLACK); // Cambiar color del texto
        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.NONE; // este ayudqa a que no se estiren los botones
        frame.add(boton, gbc);
        boton.addActionListener(e -> {
            frame.dispose(); // Cierra la ventana actual
            Iniciosesion.main(null); // Abre la ventana de inicio de sesión
        });

        frame.setVisible(true);
    }
}