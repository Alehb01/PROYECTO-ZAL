public class RegistrarEstablecimientos {

    public static void main(Object object) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'main'");
    }
    
}
