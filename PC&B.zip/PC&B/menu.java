import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Image;

public class menu {
    public static void main(String[] args) {
       
        JFrame frame = new JFrame("Menu Principal");
         // Configuración de la ventana
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH); // Abre la ventana en pantalla completa
        frame.getContentPane().setBackground(new Color(65,105,225));
        frame.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // -------- Logo arriba a la izquierda --------
        ImageIcon imagenOriginal = new ImageIcon("img/logoP.png");
        Image imagentamaño = imagenOriginal.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        JLabel labelImagen = new JLabel(new ImageIcon(imagentamaño));
        
        gbc.gridx = 0;   // columna 0
        gbc.gridy = 0;   // fila 0
        gbc.anchor = GridBagConstraints.NORTHWEST; // Alineación arriba a la izquierda
        frame.add(labelImagen, gbc);
        
        // -------- Título arriba al centro --------
        JLabel titulo = new JLabel("Menú Principal");
        titulo.setFont(titulo.getFont().deriveFont(80f));
        titulo.setForeground(Color.DARK_GRAY);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        
        gbc.gridx = 1;   // columna 1 (centro)
        gbc.gridy = 0;   // misma fila que el logo
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.gridwidth = 2; // que abarque varias columnas si es necesario
        frame.add(titulo, gbc);
        
        // -------- Botón debajo --------
        JButton btnRegis = new JButton("Registrar Establecimiento");
        btnRegis.setPreferredSize(new Dimension(400, 70));
        btnRegis.setFont(btnRegis.getFont().deriveFont(20f));
        btnRegis.setBackground(new Color(245, 255, 250));
        btnRegis.setForeground(Color.BLACK);
        
        gbc.gridx = 0;
        gbc.gridy = 1;  // debajo del título y logo
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        frame.add(btnRegis, gbc);
        btnRegis.addActionListener(e -> {
            frame.dispose(); // Cierra la ventana actual
            RegistrarEstablecimientos.main(null); // Abre la ventana de registrar establecimientos
        });
        JButton btnVer = new JButton("Ver Establecimientos");
        btnVer.setPreferredSize(new Dimension(400, 70));
        btnVer.setFont(btnVer.getFont().deriveFont(20f));
        btnVer.setBackground(new Color(245, 255, 250));
        btnVer.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 2;  // debajo del botón de registrar
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        frame.add(btnVer, gbc);
        btnVer.addActionListener(e -> {
            frame.dispose(); // Cierra la ventana actual
            VerEstablecimientos.main(null); // Abre la ventana de ver establecimientos
        });
        JButton btnElim = new JButton("Eliminar Establecimientos");
        btnElim.setPreferredSize(new Dimension(400, 70));
        btnElim.setFont(btnElim.getFont().deriveFont(20f));
        btnElim.setBackground(new Color(245, 255, 250));
        btnElim.setForeground(Color.BLACK);
        gbc.gridx = 2;
        gbc.gridy = 1;  // al lado del botón de ver
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        frame.add(btnElim, gbc);
        btnElim.addActionListener(e -> {
            frame.dispose(); // Cierra la ventana actual
            EliminarEstablecimientos.main(null); // Abre la ventana de eliminar establecimientos
        });
        JButton btnModif = new JButton("Modificar Establecimientos");
        btnModif.setPreferredSize(new Dimension(400, 70));
        btnModif.setFont(btnModif.getFont().deriveFont(20f));
        btnModif.setBackground(new Color(245, 255, 250));
        btnModif.setForeground(Color.BLACK);
        gbc.gridx = 2;
        gbc.gridy = 2; // debajo del botón de eliminar
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        frame.add(btnModif, gbc);
        btnModif.addActionListener(e -> {
            frame.dispose(); // Cierra la ventana actual
            ModificarEstablecimientos.main(null); // Abre la ventana de modificar establecimientos
        });
        frame.setVisible(true);
    }
}
